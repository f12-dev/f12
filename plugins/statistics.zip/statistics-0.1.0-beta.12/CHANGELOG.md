# Changelog

## [0.1.0-beta.9](https://github.com/flarum/statistics/compare/v0.1.0-beta.8...v0.1.0-beta.9)

### Changed
- Update compiled JavaScript sources
