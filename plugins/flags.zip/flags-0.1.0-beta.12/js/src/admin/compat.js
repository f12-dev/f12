import FlagsSettingsModal from './components/FlagsSettingsModal';

export default {
  'flags/components/FlagsSettingsModal': FlagsSettingsModal,
};
