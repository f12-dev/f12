# Changelog

## [0.1.0-beta.10](https://github.com/flarum/emoji/compare/v0.1.0-beta.8...v0.1.0-beta.10)

### Added
- Latest and greatest emojis with Twemoji 12 (#20)
