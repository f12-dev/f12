# Changelog

## [0.1.0-beta.9](https://github.com/flarum/auth-github/compare/v0.1.0-beta.8...v0.1.0-beta.9)

### Fixed
- OAuth callback URL was incorrect when Flarum was installed in a subfolder ([6504f74](https://github.com/flarum/auth-github/commit/6504f74170b8c5f7d7afb87b1a1335a583e7fdec))
